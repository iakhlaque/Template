$(".right_side_toggle").on('click', function(){
  $('#right_side_bar').toggleClass('show');
});
